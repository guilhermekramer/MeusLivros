package com.example.meuslivros

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonCadastrar = findViewById<Button>(R.id.button1)
        val buttonListarLivros = findViewById<Button>(R.id.button2)
        val ae = findViewById<Button>(R.id.button6)



       buttonCadastrar.setOnClickListener {
       val intent = Intent(this, TelaCadastro::class.java)
       startActivity(intent)
       }
       buttonListarLivros.setOnClickListener {
       val intent = Intent(this, CadastrarLivros::class.java)
      startActivity(intent)
       }

       ae.setOnClickListener {
       val intent = Intent(this, ExibirLivros::class.java)
       startActivity(intent)
       }


     }
}