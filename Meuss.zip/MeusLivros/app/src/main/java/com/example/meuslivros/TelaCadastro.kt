package com.example.meuslivros

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TelaCadastro : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_cadastro)
    }
}