package com.example.meuslivros

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase

@Dao
interface LivroDao {
    @Query("SELECT * FROM livro")
    fun getAll(): Array<Livro>

    @Query("SELECT * FROM livro WHERE lId IN (:livroids)")
    fun loadAllByIds(livroids: IntArray): List<Livro>

    @Insert
    fun insertAll( livro: Livro) : Long

    @Delete
    fun delet(livro: Livro): Int


}
@Database(entities = [Livro::class], version = 1)
abstract class LivroDatabase : RoomDatabase() {

    abstract fun LivroDao(): LivroDao

    companion object {
        @Volatile
        private var instance: LivroDatabase? = null

        fun getInstance(context: Context): LivroDatabase {
            return instance ?: synchronized(this) {
                instance ?: buildDatabase(context).also { instance = it }
            }
        }

        private fun buildDatabase(context: Context): LivroDatabase {
            return Room.databaseBuilder(
                context,
                LivroDatabase::class.java,
                "livro_database"

            ).build()
        }
    }
}

